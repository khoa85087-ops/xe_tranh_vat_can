/*
 * Motor.h
 *
 *  Created on: 4 thg 10, 2026
 *      Author: ACER
 */


#ifndef MOTOR_H
#define MOTOR_H

#include "main.h"

// Khai báo cấu trúc động cơ
typedef struct {
    TIM_HandleTypeDef *htim;
    uint32_t channel;

    GPIO_TypeDef *IN1_Port;
    uint16_t IN1_Pin;

    GPIO_TypeDef *IN2_Port;
    uint16_t IN2_Pin;

} Motor_t;

// Các hàm điều khiển
void Motor_Init(Motor_t *motor);

void Motor_SetPWM(Motor_t *motor, int16_t pwm);

void Motor_Forward(Motor_t *motor, uint16_t pwm);

void Motor_Backward(Motor_t *motor, uint16_t pwm);

void Motor_Stop(Motor_t *motor);

#endif
