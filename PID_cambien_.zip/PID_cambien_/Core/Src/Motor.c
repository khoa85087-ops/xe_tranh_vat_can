/*
 * Motor.c
 *
 *  Created on: 4 thg 10, 2026
 *      Author: ACER
 */


#include "Motor.h"

void Motor_Init(Motor_t *motor)
{
    HAL_TIM_PWM_Start(motor->htim, motor->channel);

    Motor_Stop(motor);
}

// pwm: từ -1000 đến 1000
void Motor_SetPWM(Motor_t *motor, int16_t pwm)
{
    uint16_t duty;

    if (pwm > 1000) pwm = 1000;
    if (pwm < -1000) pwm = -1000;

    if (pwm > 0)
    {
        HAL_GPIO_WritePin(motor->IN1_Port,
                          motor->IN1_Pin, GPIO_PIN_SET);

        HAL_GPIO_WritePin(motor->IN2_Port,
                          motor->IN2_Pin, GPIO_PIN_RESET);

        duty = pwm;
    }
    else if (pwm < 0)
    {
        HAL_GPIO_WritePin(motor->IN1_Port,
                          motor->IN1_Pin, GPIO_PIN_RESET);

        HAL_GPIO_WritePin(motor->IN2_Port,
                          motor->IN2_Pin, GPIO_PIN_SET);

        duty = -pwm;
    }
    else
    {
        Motor_Stop(motor);
        return;
    }

    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(motor->htim);

    uint32_t compare = ((uint32_t)duty * (arr + 1)) / 1000;

    if (compare > arr)
        compare = arr;

    __HAL_TIM_SET_COMPARE(motor->htim,
                          motor->channel, compare);
}

void Motor_Forward(Motor_t *motor, uint16_t pwm)
{
    if (pwm > 1000) pwm = 1000;

    Motor_SetPWM(motor, pwm);
}

void Motor_Backward(Motor_t *motor, uint16_t pwm)
{
    if (pwm > 1000) pwm = 1000;

    Motor_SetPWM(motor, -(int16_t)pwm);
}

void Motor_Stop(Motor_t *motor)
{
    HAL_GPIO_WritePin(motor->IN1_Port,
                      motor->IN1_Pin, GPIO_PIN_RESET);

    HAL_GPIO_WritePin(motor->IN2_Port,
                      motor->IN2_Pin, GPIO_PIN_RESET);

    __HAL_TIM_SET_COMPARE(motor->htim,
                          motor->channel, 0);
}
